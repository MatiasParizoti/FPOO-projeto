
public class Main {

	public static void main(String[] args) {
		
		
		Valor objValor = new Valor();
				
				objValor.Numeros();
	     
	}

}
