import java.util.Scanner;

public class MAIN {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in); 
		Menu objMenu = new Menu();
		objMenu.ExibirMenu();
	}
}
